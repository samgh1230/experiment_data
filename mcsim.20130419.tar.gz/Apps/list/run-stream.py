# #_threads  #_skip_1st_instrs   dir  prog_n_argv
2 0 /bin/ STREAM -p2 -n65536 -r2 -s512
4 0 /bin/ STREAM -p4 -n262144 -r2 -s512
