# #_threads  #_skip_1st_instrs   dir  prog_n_argv
# if #_threads is 0, a trace file name is specified at the location of #_skip_1st_instrs
1 0 /bin/ uname -a
