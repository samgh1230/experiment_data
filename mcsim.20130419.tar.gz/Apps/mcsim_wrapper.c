void mcsim_skip_instrs_begin()
{
}

void mcsim_skip_instrs_end()
{
}

void mcsim_spinning_begin()
{
}

void mcsim_spinning_end()
{
}

