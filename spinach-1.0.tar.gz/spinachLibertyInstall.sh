#!/bin/bash

if [[ x${LIBERTY}x == "xx" ]]; then
    echo "Please set the LIBERTY environment variable to the directory where you want to install Liberty"
    exit 1
fi

if [[ $(pwd) != $LIBERTY ]]; then
    cp liberty_spinach.tar.gz $LIBERTY
    cp spinach_libs.tar.gz $LIBERTY
    cd $LIBERTY
fi

tar -xzf liberty_spinach.tar.gz

src/scripts/scripts/l-env --LIBERTY=$LIBERTY > liberty_path_setup

. liberty_path_setup

cd src

./goLiberty

if [[ $? -ne 0 ]]; then
    echo "Liberty installer failed!"
    exit 1
fi

cd ..

tar -xzf spinach_libs.tar.gz

cd spinach_libs/dram_sim
make depend && make

if [[ ! -d $LIBERTY/lib/domains ]]; then
    mkdir $LIBERTY/lib/domains
fi

cp libDRAM.a $LIBERTY/lib/domains

cd ../libBufferedWarn
make
cp libBufferedWarn.a $LIBERTY/lib/domains

cd ../libMessageList
make
cp libMessageList.a $LIBERTY/lib/domains

cd ..
cp mp_link.sh $LIBERTY/bin

cd ..

echo;echo
echo "Success! LSE and the Spinach libs are installed in $LIBERTY"
echo "The Spinach modules go in your working directory (see getting_started.txt)."